package com.BugReportingSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BugReportingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
